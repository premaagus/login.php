--
-- Database: `db_daftar`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_daftar`
--

CREATE TABLE `form_daftar` (
  `id` int(11) NOT NULL,
  `nama` varchar(64) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_daftar`
--

INSERT INTO `form_daftar` (`id`, `nama`, `username`, `password`) VALUES
(1, 'I Wayan Aditya Semara Putra', '0', '0'),
(2, 'Aditya Semara Putra', '0', '0'),
(3, 'Aditya Semara Putra', '0', '0'),
(4, 'Aditya Semara Putra', 'adityasemaraputra', 'adityasemara');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form_daftar`
--
ALTER TABLE `form_daftar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form_daftar`
--
ALTER TABLE `form_daftar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
